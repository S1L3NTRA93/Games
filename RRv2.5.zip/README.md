***~~=======================================================~~***

**Want to update your version?**

Click [Here](https://github.com/RogersResources/main)

***~~=======================================================~~***

**Experimental Web Versions!**

Link 1 Click [Here](http://rogers.rf.gd/GAMESITE.html)

***~~=======================================================~~***

**Discord Server!**

Click [Here](https://discord.gg/bD6JFXdtg2)

Click [Here](https://e.widgetbot.io/channels/1030241184368562216/1030241186004340790) To Join As A Guest (Not Blocked!)

***~~=======================================================~~***

**DOWNLOAD TUTORIAL:** 

>1) Open our github page located [Here](https://github.com/RogersResources/main)
>
>2) Look to the middle right side of the site and click the latest release and download it
>
>3) Open your file manager app
>
>4) Click the "My files" button located around the middle-left
>
>5) Right click in the open white space (Two finger tap) and click "New folder" and name your folder anything you want
>
>6) Next, press the "Recent" button located on the top left
>
>7) You should see "main-main.zip" or something along those lines in that folder
>
>8) Drag "main-main.zip" into the folder you created, and then open the folder you created
>
>9) right click (Two finger tap) the "main-main.zip" file and press "extract" or "extract here"
>
>10) Open the "main-main" folder, and then open the "GAMESITE" folder
>
>11) Then double-click the GAMESITE file and enjoy :)

<img width="615" alt="rogersresources" src="https://user-images.githubusercontent.com/114105250/192408377-bda6d495-9811-48e7-acd0-5bc3c530e865.png">
